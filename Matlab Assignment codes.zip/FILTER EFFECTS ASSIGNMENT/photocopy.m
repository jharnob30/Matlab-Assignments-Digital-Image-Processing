clc
clear all
close all

original = imread('horse_in.jpg');
im = rgb2gray(original);
%imshow(im);
th = input("Threshold value: "); 
for i = 1 : size(im,1)
    for j = 1 : size(im,2)
        if im(i,j)>th
            im(i,j)= 250;
        else
            im(i,j) = im(i,j)*(th-im(i,j))/(th*th);
        end
    end
end
subplot(1,2,1)
imshow(original); title('Original')
subplot(1,2,2)
imshow(im); title('Photocopy')
