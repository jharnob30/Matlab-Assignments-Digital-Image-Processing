clc
clear all
close all

im = imread('mirror_in.jpg');
%imshow(im);

mirror_type = input("If horizontal mirror put 1, if verticle mirror put 2: ");
v = (size(im,2))+1;
h = (size(im,1))+1;

for i = 1 : size(im,1)
    for j = 1 : size(im,2)
        for k = 1:3
            if mirror_type == 1
                im2(i,j,k) = im(i,v-j,k);
            elseif mirror_type == 2
                im2(i,j,k) = im(h-i,j,k);
            end
        end
    end
end

subplot(1,2,1)
imshow(im); title('Original')
subplot(1,2,2)
imshow(im2); title('mirror')
