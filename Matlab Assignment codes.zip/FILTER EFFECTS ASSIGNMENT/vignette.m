clc
clear all
close all

original = imread('flowerman.jpg');
im = original;
imshow(im);

m = (size(im,1)/2);
n = (size(im,2)/2);
maxDist= (sqrt((m-1)^2+(n-1)^2));

for i = 1 : size(im,1)
    for j = 1 : size(im,2)
        for k = 1:3
            ranDist = (sqrt((m-i)^2+(n-j)^2));
            weight= 1-(ranDist/maxDist); 
            im(i,j,k)=im(i,j,k)*weight;
        end
    end
end
subplot(1,2,1)
imshow(original); title('Original')
subplot(1,2,2)
imshow(im); title('vignette')
