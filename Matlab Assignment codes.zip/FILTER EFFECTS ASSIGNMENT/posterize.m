clc
clear all
close all

original = imread('poster_in.jpg');
im = original;
%imshow(im);
input = input('Number of colors from 4 to 8: ');
if input<4 || input >8
    disp("To make it posterize, You need to select number of colors from 4 to 8. " + ...
        "but you can try different values to experiment it");
end
for i = 1 : size(im,1)
    for j = 1 : size(im,2)
        for k = 1 : 3
            f = im(i,j,k);
            for a = 1:input
               m = round(255/input);
               n=m*(a-1);  
               m=m*a;
               if f>n && f<=m
                    im(i,j,k)=m;
               end
            end
        end
    end
end

subplot(1,2,1)
imshow(original); title('Original')
subplot(1,2,2)
imshow(im); title('Posterized')