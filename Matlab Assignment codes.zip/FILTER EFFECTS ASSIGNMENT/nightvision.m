clc
clear all
close all

orginal = imread('nightvision2.jpg');
im = orginal;
imshow(im);

im(:,:,1) = im(:,:,2)/2;
im(:,:,3) = 2*im(:,:,1);
im(:,:,2) = 2*im(:,:,3);

subplot(1,2,1)
imshow(orginal); title('Orginal')
subplot(1,2,2)
imshow(im); title('Nightvision')