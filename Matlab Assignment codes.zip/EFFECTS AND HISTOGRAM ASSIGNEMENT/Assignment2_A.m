clc
clear all
close all

im = imread('us.jpg');
im1= im;
if size(im,3) == 3 % if input is rgb
     im = rgb2gray(im);
end
im = double(im);

r = size(im,1);
c = size(im,2);
n = r*c; %total number of pixels
ah = uint8(zeros(r,c));

f = zeros(256,1); %frequency/histogram
pdf = zeros(256,1); %normalized histogram, probability(f)
cdf = zeros(256,1); 
s = zeros(256,1); %equalized histogram

%calculating histogram
for i=1:size(im,1)
    for j=1:size(im,2)
        value = im(i,j);
        f(value+1)=f(value+1)+1;
    end
end

%calculating pdf,cdf,transformation function
a = 0;
for i=1:size(f)
     pdf(i) = (f(i)/n);
     a = a+pdf(i);
     cdf(i) = a;
     s(i) = round(cdf(i)*255);
end

%applying transformation function, s on image
for i=1:size(im,1)
    for j=1:size(im,2)
        ah(i,j) = s(im(i,j)+1);
    end
end

subplot(1,2,1);
imshow(mat2gray(im));title("Gray")
subplot(1,2,2);
imshow(mat2gray(ah));title("Histogram Equalized");