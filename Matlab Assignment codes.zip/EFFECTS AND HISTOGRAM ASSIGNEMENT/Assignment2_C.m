clc
clear all
close all

im = imread('us.jpg');

filterX = [-1 -2 -1; 0 0 0; 1 2 1];
filterY = [-1 0 1; -2 0 2; -1 0 1];

%Applying filter on R plane 
im1 = double(im(:,:,1));
out1 = zeros(size(im1));
for row = 2 : size(im,1) - 1
    for col = 2 : size(im,2) - 1
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im1(temp1:temp1 + 2,temp2:temp2 + 2);
        valx = sum(sum(sub_block .* filterX));
        valy = sum(sum(sub_block .* filterY));
        val = sqrt(valx.^2 + valy.^2);
        out1(row,col) = val;
    end
end
%Applying filter on G plane 
im2 = double(im(:,:,2));
out2 = zeros(size(im2));
for row = 2 : size(im,1) - 1
    for col = 2 : size(im,2) - 1
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im2(temp1:temp1 + 2,temp2:temp2 + 2);
        valx = sum(sum(sub_block .* filterX));
        valy = sum(sum(sub_block .* filterY));
        val = sqrt(valx.^2 + valy.^2);
        out2(row,col) = val;
    end
end

%Applying filter for B plane 
im3 = double(im(:,:,3));
out3 = zeros(size(im3));
for row = 2 : size(im,1) - 1
    for col = 2 : size(im,2) - 1
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im1(temp1:temp1 + 2,temp2:temp2 + 2);
        valx = sum(sum(sub_block .* filterX));
        valy = sum(sum(sub_block .* filterY));
        val = sqrt(valx.^2 + valy.^2);
        out3(row,col) = val;
    end
end

% convert back to uint8
o = uint8(cat(3, out1, out2, out3));
% imshow(o);

%RGB2GRAY conversion
gray = rgb2gray(o);
% imshow(gray);

%inversting color
f = zeros(size(gray));
for i=1:size(gray,1)
    for j=1:size(gray,2)
        f(i,j)=255-gray(i,j);
    end
end

%output
subplot(1,2,1);
imshow(im);title("original")
subplot(1,2,2);
imshow(mat2gray(gray)); title('Sketch Effect')
