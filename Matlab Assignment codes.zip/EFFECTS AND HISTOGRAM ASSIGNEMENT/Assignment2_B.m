clc
clear all
close all

original = imread('us.jpg');% // Read in your image here
r = size(original,1);
c = size(original,2);

% RGB2SEPIA CONVERSION
im = original;
inputRed = im(:,:,1); %// Extract each colour plane
inputGreen = im(:,:,2);
inputBlue = im(:,:,3);
% Create sepia tones for each channel
outputRed = (inputRed * .393) + (inputGreen *.769) + (inputBlue * .189);
outputGreen = (inputRed * .349) + (inputGreen *.686) + (inputBlue * .168);
outputBlue = (inputRed * .272) + (inputGreen *.534) + (inputBlue * .131);
% convert back to uint8
sepia = uint8(cat(3, outputRed, outputGreen, outputBlue));
imshow(sepia); %// Show sepia image

% ADD NOISE
im2 = imnoise(sepia,'gaussian');
imshow(im2); 

% BLEND
old = uint8(zeros(r,c));
for i=1:r
    for j=1:c
        for k=1:3
            old(i,j,k)=im(i,j,k)/3+im2(i,j,k)-60; %RANDOM TRY
        end
    end
end

subplot(1,2,1);
imshow(im);title("Original")
subplot(1,2,2);
imshow(old); title("Old Image Effect")