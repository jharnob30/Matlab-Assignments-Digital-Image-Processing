clc
clear all
close all

im = imread('us.jpg');

filterX = [-1 -2 -1; 0 0 0; 1 2 1];
filterY = [-1 0 1; -2 0 2; -1 0 1];

%Applying filter on R plane 
im1 = double(im(:,:,1));
out1 = zeros(size(im1));
for row = 2 : size(im,1) - 1
    for col = 2 : size(im,2) - 1
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im1(temp1:temp1 + 2,temp2:temp2 + 2);
        valx = sum(sum(sub_block .* filterX));
        valy = sum(sum(sub_block .* filterY));
        val = sqrt(valx.^2 + valy.^2);
        out1(row,col) = val;
    end
end

%Applying filter on G plane 
im2 = double(im(:,:,2));
out2 = zeros(size(im2));
for row = 2 : size(im,1) - 1
    for col = 2 : size(im,2) - 1
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im2(temp1:temp1 + 2,temp2:temp2 + 2);
        valx = sum(sum(sub_block .* filterX));
        valy = sum(sum(sub_block .* filterY));
        val = sqrt(valx.^2 + valy.^2);
        out2(row,col) = val;
    end
end

%Applying filter on B plane 
im3 = double(im(:,:,3));
out3 = zeros(size(im3));
for row = 2 : size(im,1) - 1
    for col = 2 : size(im,2) - 1
        temp1 = row - 1;
        temp2 = col - 1;
        sub_block = im1(temp1:temp1 + 2,temp2:temp2 + 2);
        valx = sum(sum(sub_block .* filterX));
        valy = sum(sum(sub_block .* filterY));
        val = sqrt(valx.^2 + valy.^2);
        out3(row,col) = val;
    end
end
% convert back to uint8
out = uint8(cat(3, out1, out2, out3)); 
% imshow(out);

% BLUR EDGE OUTPUT
sigma = 3;
filter = fspecial('gaussian',[3,3],sigma);
imeglow = imfilter(out,filter);
% imshow(imeglow);

% BLEND
r=size(im,1);
c=size(im,2);
a = 0.5;
eglow = uint8(zeros(r,c));
for i=1:r
    for j=1:c
        for k=1:3
            eglow(i,j,k)=a*im(i,j,k)+(1-a)*imeglow(i,j,k); %RANDOM TRY
        end
    end
end

subplot(1,2,1);
imshow(im);title("original")
subplot(1,2,2);
imshow(eglow); title("blend with Original")

